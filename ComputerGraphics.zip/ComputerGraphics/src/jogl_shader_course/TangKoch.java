package jogl_shader_course;

import graphicslib3D.*;
import graphicslib3D.GLSLUtils.*;

import java.nio.*;
import java.util.Scanner;

import javax.swing.*;

import static com.jogamp.opengl.GL.GL_ARRAY_BUFFER;
import static com.jogamp.opengl.GL.GL_DEPTH_BUFFER_BIT;
import static com.jogamp.opengl.GL.GL_DEPTH_TEST;
import static com.jogamp.opengl.GL.GL_FLOAT;
import static com.jogamp.opengl.GL.GL_LEQUAL;
import static com.jogamp.opengl.GL.GL_STATIC_DRAW;
import static com.jogamp.opengl.GL.GL_TRIANGLES;
import static com.jogamp.opengl.GL2ES2.GL_FRAGMENT_SHADER;
import static com.jogamp.opengl.GL2ES2.GL_VERTEX_SHADER;
import static com.jogamp.opengl.GL4.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.common.nio.Buffers;

public class TangKoch extends JFrame implements GLEventListener{
	
	private GLCanvas myCanvas;
	private int rendering_program;
	private int vao[] = new int[1];
	private int vbo[] = new int[2];
	private GLSLUtils util = new GLSLUtils();
	private float[] vertex_positions=new float[2*2];//Two points, two coordinates

	private static float side_length;
	private static int depth;
	private static int totalSegments;
	private static double totalPerimeter;
	private static double totalArea;
	
	public TangKoch(float length, int N)
	{	setTitle("Koch Snowflake");
		setSize(600, 600);
		//Making sure we get a GL4 context for the canvas
        GLProfile profile = GLProfile.get(GLProfile.GL4);
        GLCapabilities capabilities = new GLCapabilities(profile);
		myCanvas = new GLCanvas(capabilities);
 		//end GL4 context
		myCanvas.addGLEventListener(this);
		getContentPane().add(myCanvas);
		this.setVisible(true);
		side_length = length;
		depth = N;
	}
	
	private int createShaderProgram()
	{	GL4 gl = (GL4) GLContext.getCurrentGL();

		String vshaderSource[] = util.readShaderSource("shader/vert.shader.2d");
		String fshaderSource[] = util.readShaderSource("shader/frag.shader.2d");

		int vShader = gl.glCreateShader(GL_VERTEX_SHADER);
		int fShader = gl.glCreateShader(GL_FRAGMENT_SHADER);

		gl.glShaderSource(vShader, vshaderSource.length, vshaderSource, null, 0);
		gl.glShaderSource(fShader, fshaderSource.length, fshaderSource, null, 0);

		gl.glCompileShader(vShader);
		gl.glCompileShader(fShader);

		int vfprogram = gl.glCreateProgram();
		gl.glAttachShader(vfprogram, vShader);
		gl.glAttachShader(vfprogram, fShader);
		gl.glLinkProgram(vfprogram);
		return vfprogram;
	}
	
	public static void main(String[] args) {
		// Test program, Go To Run Configurations, Arguments, and add values
		
		side_length = Float.parseFloat(args[0]);	//Command line argument for side_length

		depth = Integer.parseInt(args[1]);			//Command line argument for depth
		
		new TangKoch(side_length, depth);
		
	}

	public void display(GLAutoDrawable drawable)
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
		//Define the triangle
		float[] v1=new float[2];//Two coordinates
		float[] v2=new float[2];//Two coordinates
		float[] v3=new float[2];//Two coordinates
		//The first three vertices define the starting triangle
		//Equilateral triangle centered at the origin
		
		//Bottom vertex  x and y
		v1[0]=0; v1[1]=-side_length*(float)Math.sqrt(3)/3;
		//Top left
		v2[0]=-0.5f*side_length; v2[1]=(float)Math.sqrt(3)*side_length/6;
		//Top right
		v3[0]=0.5f*side_length; v3[1]=(float)Math.sqrt(3)*side_length/6;
		//Done defining triangle
		
		//Initial values of segments, perimeter and area
		totalSegments = 3;
		totalPerimeter = 3*side_length;
		totalArea = (float) ((Math.sqrt(3)/4)*Math.pow(side_length, 2));
		
		gl.glClear(GL_DEPTH_BUFFER_BIT);

		gl.glUseProgram(rendering_program);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		
		//Each call is for each segment of the triangle
		processKoch(v2,v1, side_length, depth);	//Bottom Left triangle side
		processKoch(v3,v2, side_length, depth);	//Top triangle side
		processKoch(v1,v3, side_length, depth);	//Bottom Right triangle side
		
		//After the recursion is done, the values for that N depth are printed
		System.out.println("Depth: " + depth);
		System.out.println("Segments: " +  totalSegments);
		System.out.println("Perimenter: " + totalPerimeter);
		System.out.println("Total Area: " + totalArea);
	}
	
	
	private void processKoch(float[] v1, float[] v2, double dLength, int n) {
		double newLength = dLength/3;		//New side length
		if(n>0) {
			//Coordinates of 1/3, 1/2, 2/3 points on a line
			float[] left = new float[2];
			float[] mid = new float[2];
			float[] right = new float[2];
			for(int i = 0; i < 2; i++) {
				left[i] = v1[i] + (v2[i]-v1[i])/3;
				right[i] = v1[i] + 2*(v2[i]-v1[i])/3;
			}
			mid[0] =  ((v1[0]+v2[0])/2 + ((v2[1]-v1[1])*((float) Math.sqrt(3)/6)));
			mid[1] =  ((v1[1]+v2[1])/2 - ((v2[0]-v1[0])*((float) Math.sqrt(3)/6)));
			
			//Increase for one side of the triangle
			totalSegments+=3;											//1 line segment increased to 4 segments
			totalPerimeter+= newLength;									//Perimeter adds on 1/3 its side length 
			totalArea+= ((Math.sqrt(3)/4)*Math.pow(newLength, 2));		//Area adds on a triangle of side length newLength
			
			//Recurse
			processKoch(v1,left,newLength,n-1);		//Left side 
			processKoch(left,mid,newLength,n-1);	//Left of midpoint
			processKoch(mid,right,newLength,n-1);	//Right of midpoint
			processKoch(right,v2,newLength,n-1);	//Right side
		}
		else {
			drawKoch(v1,v2);	//Draw
		}
	}
	
	private void drawKoch(float[] v1, float[] v2) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		vertex_positions[0] = v1[0];
		vertex_positions[1] = v1[1];
		vertex_positions[2] = v2[0];
		vertex_positions[3] = v2[1];
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(vertex_positions);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);

		//Draw now
		gl.glDrawArrays(GL_LINES, 0, 4);

	}

	public void init(GLAutoDrawable drawable)
	{	GL4 gl = (GL4) drawable.getGL();
		rendering_program = createShaderProgram();
		gl.glGenVertexArrays(vao.length, vao, 0);
		gl.glBindVertexArray(vao[0]);
		gl.glGenBuffers(vbo.length, vbo, 0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);

	}
	
	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {}
	
	public void dispose(GLAutoDrawable drawable) {}
}
