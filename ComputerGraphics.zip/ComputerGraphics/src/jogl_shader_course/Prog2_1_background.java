package jogl_shader_course;

import static com.jogamp.opengl.GL4.*;

import java.nio.FloatBuffer;

import javax.swing.JFrame;

import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;

public class Prog2_1_background extends JFrame implements GLEventListener

{ private GLCanvas myCanvas;

 public Prog2_1_background()

 { setTitle("Chapter2 - program1");

 setSize(600,400);

 setLocation(200,200);

 //Making sure we get a GL4 context for the canvas

        GLProfile profile = GLProfile.get(GLProfile.GL4);

        GLCapabilities capabilities = new GLCapabilities(profile);

 myCanvas = new GLCanvas(capabilities);

  //end GL4 context

 myCanvas.addGLEventListener(this);

 getContentPane().add(myCanvas);

 setVisible(true);

 }

 public void display(GLAutoDrawable drawable)

 { 

 GL4 gl = GLContext.getCurrentGL().getGL4();

 float bkg[] = { 1.0f, 1.0f, 0.0f,1.0f};

 FloatBuffer bkgBuffer = Buffers.newDirectFloatBuffer(bkg);

 gl.glClearBufferfv(GL_COLOR, 0, bkgBuffer);

 }

 public static void main(String[] args)

 {

 final GLCapabilities caps = new GLCapabilities(GLProfile.getMaxProgrammableCore(true)); 

 new Prog2_1_background();

 }

 public void init(GLAutoDrawable drawable) 

 {

 //Print env info (version)

 System.out.println(GLContext.getCurrent().getGLVersion());

 System.out.println(GLContext.getCurrent().getGLSLVersionString());

 //end print env info

 }

 public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {}

 public void dispose(GLAutoDrawable drawable) {}

}