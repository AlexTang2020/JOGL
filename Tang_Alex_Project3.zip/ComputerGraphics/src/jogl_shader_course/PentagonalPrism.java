package jogl_shader_course;

import graphicslib3D.Point3D;
import graphicslib3D.Vector3D;
import graphicslib3D.Vertex3D;

public class PentagonalPrism {
	
	private int numVertices, numIndices, prec = 48;
	private int[] indices;
	private Vertex3D[] vertices;
	
	public PentagonalPrism() {
		InitPrism();
	}
	
	private void InitPrism() {
		numVertices = 10;	
		numIndices = 48;
		vertices = new Vertex3D[numVertices];
		indices = new int[numIndices];
		for (int i=0; i<numVertices; i++) { 
			vertices[i] = new Vertex3D(); 
		}
		

		// calculate pentagonal prism vertices
		double x1 = Math.sqrt((10.0+2.0*Math.sqrt(5.0))/5.0);
		double x2 = Math.sqrt((5.0-Math.sqrt(5.0))/10.0);
		double x3 = -Math.sqrt((5.0+2.0*Math.sqrt(5.0))/5.0);
		double y1 = (1.0+Math.sqrt(5.0))/2.0;
		double y2 = -y1;
		
		vertices[0].setLocation(new Point3D(x1, 0, 1));
		vertices[0].setS(1);
		vertices[0].setT(.5);
		vertices[1].setLocation(new Point3D(x1, 0, -1));
		vertices[2].setLocation(new Point3D(x2, y1, 1));
		vertices[2].setS(.1);
		vertices[2].setT(0);
		vertices[3].setLocation(new Point3D(x2, y1, -1));
		vertices[4].setLocation(new Point3D(x2, y2, 1));
		vertices[4].setS(.1);
		vertices[4].setT(1);
		vertices[5].setLocation(new Point3D(x2, y2, -1));
		vertices[6].setLocation(new Point3D(x3, 1, 1));
		vertices[6].setS(0);
		vertices[6].setT(0);
		vertices[7].setLocation(new Point3D(x3, 1, -1));
		vertices[8].setLocation(new Point3D(x3, -1, 1));
		vertices[8].setS(0);
		vertices[8].setT(1);
		vertices[9].setLocation(new Point3D(x3, -1, -1));
		//Sides of Pentagon
		indices[0] = 0;	indices[1] = 1;	indices[2] = 3;
		
		indices[3] = 3;	indices[4] = 0;	indices[5] = 2;
		
		indices[6] = 3;	indices[7] = 2;	indices[8] = 7;
		
		indices[9] = 2;	indices[10] = 7;	indices[11] = 6;
		
		indices[12] = 7;	indices[13] = 6;	indices[14] = 9;
		
		indices[15] = 9;	indices[16] = 8;	indices[17] = 6;
		
		indices[18] = 9;	indices[19] = 8;	indices[20] = 5;
		
		indices[21] = 8;	indices[22] = 5;	indices[23] = 4;
		
		indices[24] = 5;	indices[25] = 4;	indices[26] = 1;
		
		indices[27] = 4;	indices[28] = 0;	indices[29] = 1;
		//Top Pentagon
		indices[30] = 0;	indices[31] = 2;	indices[32] = 6;
		
		indices[33] = 0;	indices[34] = 6;	indices[35] = 8;
		
		indices[36] = 0;	indices[37] = 4;	indices[38] = 8;
		//Bottom Pentagon
		indices[39] = 1;	indices[40] = 3;	indices[41] = 7;
		
		indices[42] = 1;	indices[43] = 7;	indices[44] = 9;

		indices[45] = 1;	indices[46] = 5;	indices[47] = 9;
	}
	
	public int[] getIndices()
	{	return indices;
	}

	public Vertex3D[] getVertices()
	{	return vertices;
	}
}
