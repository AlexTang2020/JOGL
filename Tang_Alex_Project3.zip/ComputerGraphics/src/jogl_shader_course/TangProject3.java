package jogl_shader_course;

import graphicslib3D.*;
import graphicslib3D.shape.*;
import graphicslib3D.GLSLUtils.*;
import graphicslib3D.light.PositionalLight;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.nio.*;
import java.util.Scanner;

import javax.swing.*;

import static com.jogamp.opengl.GL.GL_ARRAY_BUFFER;
import static com.jogamp.opengl.GL.GL_CCW;
import static com.jogamp.opengl.GL.GL_CLAMP_TO_EDGE;
import static com.jogamp.opengl.GL.GL_CULL_FACE;
import static com.jogamp.opengl.GL.GL_DEPTH_ATTACHMENT;
import static com.jogamp.opengl.GL.GL_DEPTH_BUFFER_BIT;
import static com.jogamp.opengl.GL.GL_DEPTH_TEST;
import static com.jogamp.opengl.GL.GL_FLOAT;
import static com.jogamp.opengl.GL.GL_FRAMEBUFFER;
import static com.jogamp.opengl.GL.GL_FRONT;
import static com.jogamp.opengl.GL.GL_LEQUAL;
import static com.jogamp.opengl.GL.GL_NONE;
import static com.jogamp.opengl.GL.GL_POLYGON_OFFSET_FILL;
import static com.jogamp.opengl.GL.GL_STATIC_DRAW;
import static com.jogamp.opengl.GL.GL_TEXTURE0;
import static com.jogamp.opengl.GL.GL_TEXTURE1;
import static com.jogamp.opengl.GL.GL_TEXTURE_2D;
import static com.jogamp.opengl.GL.GL_TEXTURE_WRAP_S;
import static com.jogamp.opengl.GL.GL_TEXTURE_WRAP_T;
import static com.jogamp.opengl.GL.GL_TRIANGLES;
import static com.jogamp.opengl.GL2ES2.GL_FRAGMENT_SHADER;
import static com.jogamp.opengl.GL2ES2.GL_VERTEX_SHADER;
import static com.jogamp.opengl.GL2ES3.GL_COLOR;
import static com.jogamp.opengl.GL4.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.math.Matrix4;
import com.jogamp.opengl.util.*;
import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.util.texture.*;

public class TangProject3 extends JFrame implements GLEventListener, KeyListener{

	private GLCanvas myCanvas;
	private int rendering_program0, rendering_program1, rendering_program2;
	private String[] vBlinn1ShaderSource, vBlinn2ShaderSource, fBlinn2ShaderSource;
	private GLSLUtils util = new GLSLUtils();
	private int vao[] = new int[1];	
	private int vbo[] = new int[20];
	private static final float SPEED = 0.1f;

	private float cameraX, cameraY, cameraZ;
	private Vector3D cameraPos;
	private Vector3D fwd;
	private Vector3D up;
	private Matrix3D camera = new Matrix3D();
	private float pitch = 0.0f;
	private float yaw = -90.0f;
	private float aspect;
	
	private boolean toggleAxes = true;
	private Material mat;
	private PositionalLight pointLight = new PositionalLight();
	private float[] globalAmbient = new float[] {0.7f, 0.7f, 0.7f, 1.0f};
	private float[] lightOff = new float[] {0.0f,0.0f,0.0f,0.0f};
	private float[] lightOn = new float[] {1.0f,1.0f,1.0f,1.0f};
	private float lightX, lightY, lightZ;
	private Point3D lightPos;
	private Vector3D upLight;
	private Vector3D fwdLight;
	private Matrix3D light = new Matrix3D();
	private float pitchLight = 0.0f;
	private float yawLight = 0.0f;
	
	private int numObjVertices;
	private ImportedModel shuttle;
	private int shuttleTexture;
	private Texture joglShuttleTexture;
	
	private Sphere sphere = new Sphere(24);
	private int sphereTexture;
	private Texture joglSphereTexture;
	
	private Sphere sphere2 = new Sphere(24);
	private int sphere2Texture;
	private Texture joglSphere2Texture;
	
	private Sphere sphere3 = new Sphere(24);
	private int sphere3Texture;
	private Texture joglSphere3Texture;
	
	private int skyboxTexture;
	private Texture joglSkyboxTexture;
	
	private int mv_location, proj_location, n_location;

	private Matrix3D m_matrix = new Matrix3D();
	private Matrix3D v_matrix = new Matrix3D();
	private Matrix3D mv_matrix = new Matrix3D();
	private Matrix3D proj_matrix = new Matrix3D();

	
	// shadow stuff
	private int scSizeX, scSizeY;
	private int [] shadow_tex = new int[1];
	private int [] shadow_buffer = new int[1];
	private Matrix3D lightV_matrix = new Matrix3D();
	private Matrix3D lightP_matrix = new Matrix3D();
	private Matrix3D shadowMVP1 = new Matrix3D();
	private Matrix3D shadowMVP2 = new Matrix3D();
	private Matrix3D b = new Matrix3D();
	
	public TangProject3() {
		setTitle("Project 3");
		setSize(800, 800);
		myCanvas = new GLCanvas();
		myCanvas.addGLEventListener(this);
		myCanvas.addKeyListener(this);;
		getContentPane().add(myCanvas);
		this.setVisible(true);
		FPSAnimator animator = new FPSAnimator(myCanvas, 50);
		animator.start();
	}
	
	public static void main(String[] args) {
		/*Scanner scan = new Scanner(System.in);
		scan.nextLine();
		scan.close();*/
		new TangProject3();
	}
	
	public void init(GLAutoDrawable arg0) {		
		GL4 gl = (GL4) GLContext.getCurrentGL();
		rendering_program0 = createSkyboxShaderProgram();
		createShaderPrograms();
		
		cameraX = 0.0f; cameraY = 0.0f; cameraZ = 5.0f;
		cameraPos = new Vector3D(cameraX, cameraY, cameraZ);
		up = new Vector3D (0.0f, 1.0f, 0.0f);
		
		lightX = 0.0f; lightY = 5.0f; lightZ = 0.0f;
		lightPos = new Point3D(lightX, lightY, lightZ);
		upLight = new Vector3D(0.0f, 1.0f, 0.0f);
		fwdLight = new Vector3D(0.0f, 0.0f, -1.0f);
		
		shuttle = new ImportedModel("shuttle.obj");

		setUpVertices();
		setupShadowBuffers();
		
		b.setElementAt(0,0,0.5);b.setElementAt(0,1,0.0);b.setElementAt(0,2,0.0);b.setElementAt(0,3,0.5f);
		b.setElementAt(1,0,0.0);b.setElementAt(1,1,0.5);b.setElementAt(1,2,0.0);b.setElementAt(1,3,0.5f);
		b.setElementAt(2,0,0.0);b.setElementAt(2,1,0.0);b.setElementAt(2,2,0.5);b.setElementAt(2,3,0.5f);
		b.setElementAt(3,0,0.0);b.setElementAt(3,1,0.0);b.setElementAt(3,2,0.0);b.setElementAt(3,3,1.0f);
		
		// may reduce shadow border artifacts
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		
		
		joglSphereTexture = loadTexture("textures/redWall.jpg");
		sphereTexture = joglSphereTexture.getTextureObject();
		
		joglSphere2Texture = loadTexture("textures/blueWall.jpg");
		sphere2Texture = joglSphere2Texture.getTextureObject();
		
		joglSphere3Texture = loadTexture("textures/yellowWall.jpg");
		sphere3Texture = joglSphere3Texture.getTextureObject();
		
		joglShuttleTexture = loadTexture("textures/spstob_1.jpg");
		shuttleTexture = joglShuttleTexture.getTextureObject();
		
		joglSkyboxTexture = loadTexture("textures/alienSkybox.jpg");
		skyboxTexture = joglSkyboxTexture.getTextureObject();
	}
	
	public void display(GLAutoDrawable arg0) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		
		//  build the PROJECTION matrix
		pointLight.setPosition(lightPos);
		aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
		proj_matrix = perspective(60.0f, aspect, 0.1f, 1000.0f);

		float bkg[] = { 0.0f, 0.0f, 0.0f, 1.0f };
		FloatBuffer bkgBuffer = Buffers.newDirectFloatBuffer(bkg);
		gl.glClearBufferfv(GL_COLOR, 0, bkgBuffer);

		
		v_matrix.setToIdentity();
		fwd = new Vector3D(getFwdX(pitch, yaw), getFwdY(pitch), getFwdZ(pitch, yaw));
		camera = lookAt(cameraPos, up, fwd);
		v_matrix.concatenate(camera);
		v_matrix.translate(-cameraPos.getX(),-cameraPos.getY(),-cameraPos.getZ());
				
		gl.glUseProgram(rendering_program0);
				
		//  build the MODEL matrix
		m_matrix.setToIdentity();
		m_matrix.translate(cameraPos.getX(),cameraPos.getY(),cameraPos.getZ());
		m_matrix.scale(10.0f, 10.0f, 10.0f);
		//  build the MODEL-VIEW matrix
		mv_matrix.setToIdentity();
		mv_matrix.concatenate(v_matrix);
		mv_matrix.concatenate(m_matrix);
				
		mv_location = gl.glGetUniformLocation(rendering_program0, "mv_matrix");
		proj_location = gl.glGetUniformLocation(rendering_program0, "proj_matrix");

		gl.glUniformMatrix4fv(mv_location, 1, false, mv_matrix.getFloatValues(), 0);
		gl.glUniformMatrix4fv(proj_location, 1, false, proj_matrix.getFloatValues(), 0);
				
		// set up vertices buffer
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[18]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
								
		// set up texture coordinates buffer
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[19]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

		// activate the skybox texture
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, skyboxTexture);

		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);	// cube is CW, but we are viewing the inside
		gl.glDisable(GL_DEPTH_TEST);
		gl.glDrawArrays(GL_TRIANGLES, 0, 36);
		gl.glFrontFace(GL_CW);
		gl.glEnable(GL_DEPTH_TEST);
		
		if(toggleAxes) {
			fwdLight = new Vector3D(getFwdX(pitchLight, yawLight), getFwdY(pitchLight), getFwdZ(pitchLight, yawLight));
			light = lookAt(new Vector3D(-lightPos.getX(), -lightPos.getY(), -lightPos.getZ()), upLight, fwdLight);
			pointLight.setPosition(lightPos);
			
			m_matrix.setToIdentity();
			m_matrix.concatenate(light);
			m_matrix.scale(0.1f, 0.1f, 0.1f);
			
			mv_matrix.setToIdentity();
			mv_matrix.concatenate(v_matrix);
			mv_matrix.concatenate(m_matrix);
			
			gl.glUniformMatrix4fv(mv_location, 1, false, mv_matrix.getFloatValues(), 0);
			gl.glUniformMatrix4fv(proj_location, 1, false, proj_matrix.getFloatValues(), 0);

			// set up sphere vertices buffer
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
			gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(0);
						
			// set up sphere texture coordinates buffer
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
			gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(1);
						
			gl.glBindTexture(GL_TEXTURE_2D, sphere3Texture);
			
			gl.glDrawArrays(GL_TRIANGLES, 0, sphere3.getIndices().length);
		}
		
		
		gl.glBindFramebuffer(GL_FRAMEBUFFER, shadow_buffer[0]);
		gl.glFramebufferTexture(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, shadow_tex[0], 0);
	
		gl.glDrawBuffer(GL_NONE);
		gl.glEnable(GL_DEPTH_TEST);

		gl.glEnable(GL_POLYGON_OFFSET_FILL);	// for reducing
		gl.glPolygonOffset(2.0f, 4.0f);			//  shadow artifacts

		passOne();
		
		gl.glDisable(GL_POLYGON_OFFSET_FILL);	// artifact reduction, continued
		
		gl.glBindFramebuffer(GL_FRAMEBUFFER, 0);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, shadow_tex[0]);
	
		gl.glDrawBuffer(GL_FRONT);
		
		passTwo();
			
	}
	
	public void dispose(GLAutoDrawable drawable) {
		GL4 gl = (GL4) drawable.getGL();
		gl.glDeleteVertexArrays(1, vao, 0);
	}

	public void reshape(GLAutoDrawable drawable, int arg1, int arg2, int arg3, int arg4) {
		setupShadowBuffers();
	}

	public void keyPressed(KeyEvent ke) {
		char pressed = ke.getKeyChar();
		int arrowKeys = ke.getKeyCode();
		switch (pressed) {
		case 'w':
			cameraPos = cameraPos.add(new Vector3D(camera.elementAt(2, 0), camera.elementAt(2, 1), camera.elementAt(2, 2)).mult(-SPEED));
			break;
		case 's':
			cameraPos = cameraPos.add(new Vector3D(camera.elementAt(2, 0), camera.elementAt(2, 1), camera.elementAt(2, 2)).mult(SPEED));
			break;
		case 'a':
			cameraPos = cameraPos.add(new Vector3D(camera.elementAt(0, 0), camera.elementAt(0, 1), camera.elementAt(0, 2)).mult(-SPEED));
			break;
		case 'd':
			cameraPos = cameraPos.add(new Vector3D(camera.elementAt(0, 0), camera.elementAt(0, 1), camera.elementAt(0, 2)).mult(SPEED));
			break;
		case 'e':
			cameraPos = cameraPos.add(new Vector3D(camera.elementAt(1, 0), camera.elementAt(1, 1), camera.elementAt(1, 2)).mult(-SPEED));
			break;
		case 'q':
			cameraPos = cameraPos.add(new Vector3D(camera.elementAt(1, 0), camera.elementAt(1, 1), camera.elementAt(1, 2)).mult(SPEED));
			break;
		//Change Light Position
		case 'i':
			lightPos = lightPos.add(new Point3D(light.elementAt(2, 0), light.elementAt(2, 1), light.elementAt(2, 2)).mult(-SPEED));
			break;
		case 'k':
			lightPos = lightPos.add(new Point3D(light.elementAt(2, 0), light.elementAt(2, 1), light.elementAt(2, 2)).mult(SPEED));
			break;
		case 'j':
			lightPos = lightPos.add(new Point3D(light.elementAt(0, 0), light.elementAt(0, 1), light.elementAt(0, 2)).mult(-SPEED));
			break;
		case 'l':
			lightPos = lightPos.add(new Point3D(light.elementAt(0, 0), light.elementAt(0, 1), light.elementAt(0, 2)).mult(SPEED));
			break;
		case 'u':
			lightPos = lightPos.add(new Point3D(light.elementAt(1, 0), light.elementAt(1, 1), light.elementAt(1, 2)).mult(SPEED));
			break;
		case 'o':
			lightPos = lightPos.add(new Point3D(light.elementAt(1, 0), light.elementAt(1, 1), light.elementAt(1, 2)).mult(-SPEED));
			break;
		case ' ':
			toggleAxes = !toggleAxes;
		}	
		switch(arrowKeys) {
		case KeyEvent.VK_UP:
			pitch++;
			break;
		case KeyEvent.VK_DOWN:
			pitch--;
			break;
		case KeyEvent.VK_RIGHT:
			yaw++;
			break;
		case KeyEvent.VK_LEFT:
			yaw--;
			break;
		}
	}

	public void keyReleased(KeyEvent arg0) {}

	public void keyTyped(KeyEvent arg0) {}
	
	private int createSkyboxShaderProgram() {
		GL4 gl = (GL4) GLContext.getCurrentGL();

		String vshaderSource[] = util.readShaderSource("project3/vert.shader");	
		String fshaderSource[] = util.readShaderSource("project3/frag.shader");

		int vShader = gl.glCreateShader(GL_VERTEX_SHADER);
		int fShader = gl.glCreateShader(GL_FRAGMENT_SHADER);

		gl.glShaderSource(vShader, vshaderSource.length, vshaderSource, null, 0);
		gl.glShaderSource(fShader, fshaderSource.length, fshaderSource, null, 0);

		gl.glCompileShader(vShader);
		gl.glCompileShader(fShader);

		int vfprogram = gl.glCreateProgram();
		gl.glAttachShader(vfprogram, vShader);
		gl.glAttachShader(vfprogram, fShader);
		gl.glLinkProgram(vfprogram);
		return vfprogram;
	}
	
	private void createShaderPrograms()
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
		int[] vertCompiled = new int[1];
		int[] fragCompiled = new int[1];

		vBlinn1ShaderSource = util.readShaderSource("project3/blinnVert1.shader");
		vBlinn2ShaderSource = util.readShaderSource("project3/blinnVert2.shader");
		fBlinn2ShaderSource = util.readShaderSource("project3/blinnFrag2.shader");

		int vertexShader1 = gl.glCreateShader(GL_VERTEX_SHADER);
		int vertexShader2 = gl.glCreateShader(GL_VERTEX_SHADER);
		int fragmentShader2 = gl.glCreateShader(GL_FRAGMENT_SHADER);

		gl.glShaderSource(vertexShader1, vBlinn1ShaderSource.length, vBlinn1ShaderSource, null, 0);
		gl.glShaderSource(vertexShader2, vBlinn2ShaderSource.length, vBlinn2ShaderSource, null, 0);
		gl.glShaderSource(fragmentShader2, fBlinn2ShaderSource.length, fBlinn2ShaderSource, null, 0);

		gl.glCompileShader(vertexShader1);
		gl.glCompileShader(vertexShader2);
		gl.glCompileShader(fragmentShader2);

		rendering_program1 = gl.glCreateProgram();
		rendering_program2 = gl.glCreateProgram();

		gl.glAttachShader(rendering_program1, vertexShader1);
		gl.glAttachShader(rendering_program2, vertexShader2);
		gl.glAttachShader(rendering_program2, fragmentShader2);

		gl.glLinkProgram(rendering_program1);
		gl.glLinkProgram(rendering_program2);
	}


	
	
	
	private void setUpVertices() {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		gl.glGenVertexArrays(vao.length, vao, 0);
		gl.glBindVertexArray(vao[0]);
		gl.glGenBuffers(vbo.length, vbo, 0);
		
		
		setUpSphere(sphere, 0);
		setUpSphere(sphere2, 1);
		setUpImport(shuttle, 2);
		setUpSphere(sphere3, 3);
		setUpSkybox();
	}
	

	private void setUpSphere(Sphere s, int n) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		
		Vertex3D[] vertices = s.getVertices();
		int[] indices = s.getIndices();
		
		float[] pvalues = new float[indices.length*3];
		float[] tvalues = new float[indices.length*2];	
		float[] nvalues = new float[indices.length*3];

		for (int i=0; i<indices.length; i++)
		{	
			pvalues[i*3] = (float) (vertices[indices[i]]).getX();
			pvalues[i*3+1] = (float) (vertices[indices[i]]).getY();
			pvalues[i*3+2] = (float) (vertices[indices[i]]).getZ();
			tvalues[i*2] = (float) (vertices[indices[i]]).getS();
			tvalues[i*2+1] = (float) (vertices[indices[i]]).getT();
			nvalues[i*3] = (float) (vertices[indices[i]]).getNormalX();
			nvalues[i*3+1]= (float)(vertices[indices[i]]).getNormalY();
			nvalues[i*3+2]=(float) (vertices[indices[i]]).getNormalZ();
		}		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3*n]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(pvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3*n+1]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(tvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3*n+2]);
		FloatBuffer norBuf = Buffers.newDirectFloatBuffer(nvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, norBuf.limit()*4,norBuf, GL_STATIC_DRAW);
	}
	
	private void setUpImport(ImportedModel im, int n) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		
		Vertex3D[] vertices = im.getVertices();
		numObjVertices = im.getNumVertices();
		
		float[] pvalues = new float[numObjVertices*3];
		float[] tvalues = new float[numObjVertices*2];
		float[] nvalues = new float[numObjVertices*3];

		for (int i=0; i<numObjVertices; i++)
		{	pvalues[i*3]   = (float) (vertices[i]).getX();
			pvalues[i*3+1] = (float) (vertices[i]).getY();
			pvalues[i*3+2] = (float) (vertices[i]).getZ();
			tvalues[i*2]   = (float) (vertices[i]).getS();
			tvalues[i*2+1] = (float) (vertices[i]).getT();
			nvalues[i*3]   = (float) (vertices[i]).getNormalX();
			nvalues[i*3+1] = (float) (vertices[i]).getNormalY();
			nvalues[i*3+2] = (float) (vertices[i]).getNormalZ();
		}
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3*n]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(pvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3*n+1]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(tvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3*n+2]);
		FloatBuffer norBuf = Buffers.newDirectFloatBuffer(nvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, norBuf.limit()*4,norBuf, GL_STATIC_DRAW);
	}
	
	private void setUpSkybox() {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		float[] cube_vertices =
	        {	-1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, 1.0f,  1.0f, -1.0f, -1.0f,  1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, 1.0f, -1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
			1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f, 1.0f,  1.0f, -1.0f,
			1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f, -1.0f,  1.0f,  1.0f, 1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f, -1.0f, -1.0f,  1.0f, -1.0f, -1.0f,  1.0f,  1.0f,
			-1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f, -1.0f,
			1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, -1.0f,  1.0f,
			-1.0f,  1.0f, -1.0f, 1.0f,  1.0f, -1.0f, 1.0f,  1.0f,  1.0f,
			1.0f,  1.0f,  1.0f, -1.0f,  1.0f,  1.0f, -1.0f,  1.0f, -1.0f
		};

		float[] cube_texture_coord =
        	{	.25f,  .666666666f, .25f, .3333333333f, .5f, .3333333333f,	// front face lower left
			.5f, .333333333333f, .5f,  .66666666666f, .25f,  .66666666666f,	// front face upper right
			.5f, .3333333333f, .75f, .33333333333f,  .5f,  .6666666666f,	// right face lower left
			.75f, .33333333333f,  .75f,  .66666666666f, .5f,  .6666666666f,	// right face upper right
			.75f, .3333333333f,  1.0f, .3333333333f, .75f,  .66666666666f,	// back face lower
			1.0f, .3333333333f, 1.0f,  .6666666666f, .75f,  .6666666666f,	// back face upper
			0.0f, .333333333f,  .25f, .333333333f, 0.0f,  .666666666f,	// left face lower
			.25f, .333333333f, .25f,  .666666666f, 0.0f,  .666666666f,	// left face upper
			.25f, 0.0f,  .5f, 0.0f,  .5f, .333333333f,			// bottom face front
			.5f, .333333333f, .25f, .333333333f, .25f, 0.0f,		// bottom face back
			.25f,  .666666666f, .5f,  .666666666f, .5f,  1.0f,		// top face back
			.5f,  1.0f,  .25f,  1.0f, .25f,  .666666666f			// top face front
		};
		
		// load the cube vertex coordinates 
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[18]);
		FloatBuffer cubeVertBuf = Buffers.newDirectFloatBuffer(cube_vertices);
		gl.glBufferData(GL_ARRAY_BUFFER, cubeVertBuf.limit()*4, cubeVertBuf, GL_STATIC_DRAW);
		
		// load the cube texture coordinates
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[19]);
		FloatBuffer cubeTexBuf = Buffers.newDirectFloatBuffer(cube_texture_coord);
		gl.glBufferData(GL_ARRAY_BUFFER, cubeTexBuf.limit()*4, cubeTexBuf, GL_STATIC_DRAW);
	}
	
	private void installLights(int rendering_program, Matrix3D v_matrix) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		Material currentMaterial = mat;
		
		Point3D lightP = pointLight.getPosition();
		Point3D lightPv = lightP.mult(v_matrix);
		float [] viewspaceLightPos = new float[] { (float) lightPv.getX(), (float) lightPv.getY(), (float) lightPv.getZ() };

		// set the current globalAmbient settings
		int globalAmbLoc = gl.glGetUniformLocation(rendering_program, "globalAmbient");
		gl.glProgramUniform4fv(rendering_program, globalAmbLoc, 1, globalAmbient, 0);
	
		// get the locations of the light and material fields in the shader
		int ambLoc = gl.glGetUniformLocation(rendering_program, "light.ambient");
		int diffLoc = gl.glGetUniformLocation(rendering_program, "light.diffuse");
		int specLoc = gl.glGetUniformLocation(rendering_program, "light.specular");
		int posLoc = gl.glGetUniformLocation(rendering_program, "light.position");
		int MambLoc = gl.glGetUniformLocation(rendering_program, "material.ambient");
		int MdiffLoc = gl.glGetUniformLocation(rendering_program, "material.diffuse");
		int MspecLoc = gl.glGetUniformLocation(rendering_program, "material.specular");
		int MshiLoc = gl.glGetUniformLocation(rendering_program, "material.shininess");
	
		//  set the uniform light and material values in the shader
		gl.glProgramUniform4fv(rendering_program, ambLoc, 1, pointLight.getAmbient(), 0);
		gl.glProgramUniform4fv(rendering_program, diffLoc, 1, pointLight.getDiffuse(), 0);
		gl.glProgramUniform4fv(rendering_program, specLoc, 1, pointLight.getSpecular(), 0);
		gl.glProgramUniform3fv(rendering_program, posLoc, 1, viewspaceLightPos, 0);
		gl.glProgramUniform4fv(rendering_program, MambLoc, 1, currentMaterial.getAmbient(), 0);
		gl.glProgramUniform4fv(rendering_program, MdiffLoc, 1, currentMaterial.getDiffuse(), 0);
		gl.glProgramUniform4fv(rendering_program, MspecLoc, 1, currentMaterial.getSpecular(), 0);
		gl.glProgramUniform1f(rendering_program, MshiLoc, currentMaterial.getShininess());
	}
	
	public void setupShadowBuffers()
	{	GL4 gl = (GL4) GLContext.getCurrentGL();
		scSizeX = myCanvas.getWidth();
		scSizeY = myCanvas.getHeight();
	
		gl.glGenFramebuffers(1, shadow_buffer, 0);
	
		gl.glGenTextures(1, shadow_tex, 0);
		gl.glBindTexture(GL_TEXTURE_2D, shadow_tex[0]);
		gl.glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT32,
						scSizeX, scSizeY, 0, GL_DEPTH_COMPONENT, GL_FLOAT, null);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
		gl.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
	}
	
	private void passOne() {
			GL4 gl = (GL4) GLContext.getCurrentGL();
		
			gl.glUseProgram(rendering_program1);
			Point3D origin = new Point3D(0.0, 0.0, 0.0);
			lightV_matrix.setToIdentity();
			lightP_matrix.setToIdentity();
		
			lightV_matrix = lookAt(pointLight.getPosition(), origin, upLight);
			lightP_matrix = perspective(50.0f, aspect, 0.1f, 1000.0f);

			// draw the torus
			
			m_matrix.setToIdentity();
			m_matrix.translate(0.0f, 0.0f, 0.0f);
			
			shadowMVP1.setToIdentity();
			shadowMVP1.concatenate(lightP_matrix);
			shadowMVP1.concatenate(lightV_matrix);
			shadowMVP1.concatenate(m_matrix);
			int shadow_location = gl.glGetUniformLocation(rendering_program1, "shadowMVP");
			gl.glUniformMatrix4fv(shadow_location, 1, false, shadowMVP1.getFloatValues(), 0);
			
			// set up torus vertices buffer
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
			gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(0);	
		
			gl.glClear(GL_DEPTH_BUFFER_BIT);
			gl.glEnable(GL_CULL_FACE);
			gl.glFrontFace(GL_CCW);
			gl.glEnable(GL_DEPTH_TEST);
			gl.glDepthFunc(GL_LEQUAL);

			gl.glDrawArrays(GL_TRIANGLES, 0, sphere.getIndices().length);
			
			m_matrix.setToIdentity();
			m_matrix.translate(5.0f, 0.0f, 0.0f);

			shadowMVP1.setToIdentity();
			shadowMVP1.concatenate(lightP_matrix);
			shadowMVP1.concatenate(lightV_matrix);
			shadowMVP1.concatenate(m_matrix);

			gl.glUniformMatrix4fv(shadow_location, 1, false, shadowMVP1.getFloatValues(), 0);
			
			// set up vertices buffer
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
			gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(0);

			gl.glEnable(GL_CULL_FACE);
			gl.glFrontFace(GL_CCW);
			gl.glEnable(GL_DEPTH_TEST);
			gl.glDepthFunc(GL_LEQUAL);
		
			gl.glDrawArrays(GL_TRIANGLES, 0, sphere2.getIndices().length);
			
			m_matrix.setToIdentity();
			m_matrix.translate(-5.0f, 0.0f, 0.0f);

			shadowMVP1.setToIdentity();
			shadowMVP1.concatenate(lightP_matrix);
			shadowMVP1.concatenate(lightV_matrix);
			shadowMVP1.concatenate(m_matrix);

			gl.glUniformMatrix4fv(shadow_location, 1, false, shadowMVP1.getFloatValues(), 0);
			
			// set up vertices buffer
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
			gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(0);

			gl.glEnable(GL_CULL_FACE);
			gl.glFrontFace(GL_CCW);
			gl.glEnable(GL_DEPTH_TEST);
			gl.glDepthFunc(GL_LEQUAL);
		
			gl.glDrawArrays(GL_TRIANGLES, 0, shuttle.getVertices().length);
	}
	
	private void passTwo() {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		
		gl.glUseProgram(rendering_program2);
		
		mat = graphicslib3D.Material.SILVER;		
		
		mv_location = gl.glGetUniformLocation(rendering_program2, "mv_matrix");
		proj_location = gl.glGetUniformLocation(rendering_program2, "proj_matrix");
		n_location = gl.glGetUniformLocation(rendering_program2, "normalMat");
		int shadow_location = gl.glGetUniformLocation(rendering_program2,  "shadowMVP");
	
		m_matrix.setToIdentity();
		m_matrix.translate(0.0f,0.0f,0.0f);
		
		if(toggleAxes) {
			pointLight.setDiffuse(lightOn);
			pointLight.setSpecular(lightOn);
		}
		else {
			pointLight.setDiffuse(lightOff);
			pointLight.setSpecular(lightOff);
		}
		
		installLights(rendering_program2, v_matrix);
		
		//  build the MODEL-VIEW matrix
		mv_matrix.setToIdentity();
		mv_matrix.concatenate(v_matrix);
		mv_matrix.concatenate(m_matrix);
		
		shadowMVP2.setToIdentity();
		shadowMVP2.concatenate(b);
		shadowMVP2.concatenate(lightP_matrix);
		shadowMVP2.concatenate(lightV_matrix);
		shadowMVP2.concatenate(m_matrix);
		
		//  put the MV and PROJ matrices into the corresponding uniforms
		gl.glUniformMatrix4fv(mv_location, 1, false, mv_matrix.getFloatValues(), 0);
		gl.glUniformMatrix4fv(proj_location, 1, false, proj_matrix.getFloatValues(), 0);
		gl.glUniformMatrix4fv(n_location, 1, false, (mv_matrix.inverse()).transpose().getFloatValues(), 0);
		gl.glUniformMatrix4fv(shadow_location, 1, false, shadowMVP2.getFloatValues(), 0);
		

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);	
	
		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, sphereTexture);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);
		
		gl.glClear(GL_DEPTH_BUFFER_BIT);
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);
	
		gl.glDrawArrays(GL_TRIANGLES, 0, sphere.getIndices().length);

		//installLights(rendering_program2, v_matrix);

		//  build the MODEL matrix
		m_matrix.setToIdentity();
		m_matrix.translate(5.0f, 0.0f, 0.0f);

		//  build the MODEL-VIEW matrix
		mv_matrix.setToIdentity();
		mv_matrix.concatenate(v_matrix);
		mv_matrix.concatenate(m_matrix);
		
		shadowMVP2.setToIdentity();
		shadowMVP2.concatenate(b);
		shadowMVP2.concatenate(lightP_matrix);
		shadowMVP2.concatenate(lightV_matrix);
		shadowMVP2.concatenate(m_matrix);
		gl.glUniformMatrix4fv(shadow_location, 1, false, shadowMVP2.getFloatValues(), 0);

		//  put the MV and PROJ matrices into the corresponding uniforms
		gl.glUniformMatrix4fv(mv_location, 1, false, mv_matrix.getFloatValues(), 0);
		gl.glUniformMatrix4fv(proj_location, 1, false, proj_matrix.getFloatValues(), 0);
		gl.glUniformMatrix4fv(n_location, 1, false, (mv_matrix.inverse()).transpose().getFloatValues(), 0);
		
		// set up vertices buffer
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, sphere2Texture);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);
		
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, sphere2.getIndices().length);

		//installLights(rendering_program2, v_matrix);

		m_matrix.setToIdentity();
		m_matrix.translate(-5.0f, 0.0f, 0.0f);

		//  build the MODEL-VIEW matrix
		mv_matrix.setToIdentity();
		mv_matrix.concatenate(v_matrix);
		mv_matrix.concatenate(m_matrix);
		
		shadowMVP2.setToIdentity();
		shadowMVP2.concatenate(b);
		shadowMVP2.concatenate(lightP_matrix);
		shadowMVP2.concatenate(lightV_matrix);
		shadowMVP2.concatenate(m_matrix);
		gl.glUniformMatrix4fv(shadow_location, 1, false, shadowMVP2.getFloatValues(), 0);

		//  put the MV and PROJ matrices into the corresponding uniforms
		gl.glUniformMatrix4fv(mv_location, 1, false, mv_matrix.getFloatValues(), 0);
		gl.glUniformMatrix4fv(proj_location, 1, false, proj_matrix.getFloatValues(), 0);
		gl.glUniformMatrix4fv(n_location, 1, false, (mv_matrix.inverse()).transpose().getFloatValues(), 0);
		
		// set up vertices buffer
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);

		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);

		gl.glActiveTexture(GL_TEXTURE1);
		gl.glBindTexture(GL_TEXTURE_2D, shuttleTexture);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
		gl.glVertexAttribPointer(2, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(2);
		
		gl.glEnable(GL_CULL_FACE);
		gl.glFrontFace(GL_CCW);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDepthFunc(GL_LEQUAL);

		gl.glDrawArrays(GL_TRIANGLES, 0, shuttle.getVertices().length);
	}
	
	private Matrix3D lookAt(Vector3D eye, Vector3D y, Vector3D fwd) {
		
		//Used for fixed camera, target only needed for fixed
		//Vector3D targetV = new Vector3D(target);
		//Vector3D fwd = (targetV.minus(eyeV)).normalize();
		
		Vector3D side = (fwd.cross(y)).normalize();
		Vector3D up = (side.cross(fwd)).normalize();
		
		Matrix3D look = new Matrix3D();
		look.setElementAt(0, 0, side.getX());
		look.setElementAt(1, 0, up.getX());
		look.setElementAt(2, 0, -fwd.getX());
		look.setElementAt(3, 0, 0.0f);
		look.setElementAt(0, 1, side.getY());
		look.setElementAt(1, 1, up.getY());
		look.setElementAt(2, 1, -fwd.getY());
		look.setElementAt(3, 1, 0.0f);
		look.setElementAt(0, 2, side.getZ());
		look.setElementAt(1, 2, up.getZ());
		look.setElementAt(2, 2, -fwd.getZ());
		look.setElementAt(3, 2, 0.0f);
		look.setElementAt(0, 3, side.dot(eye.mult(-1)));
		look.setElementAt(1, 3, up.dot(eye.mult(-1)));
		look.setElementAt(2, 3, fwd.mult(-1).dot(eye.mult(-1)));
		look.setElementAt(3, 3, 1.0f);
		return(look);
	}
	
	public Texture loadTexture(String textureFileName)
	{	Texture tex = null;
		try { tex = TextureIO.newTexture(new File(textureFileName), false); }
		catch (Exception e) { e.printStackTrace(); }
		return tex;
	}
	
	public double getFwdX(float pitch, float yaw) {
		double fwdX = Math.cos(Math.toRadians(pitch)) * Math.cos(Math.toRadians(yaw));
		return fwdX;
	}

	public double getFwdY(float pitch) {
		double fwdY = Math.sin(Math.toRadians(pitch));
		return fwdY;
	}

	public double getFwdZ(float pitch, float yaw) {
		double fwdZ =  Math.cos(Math.toRadians(pitch)) * Math.sin(Math.toRadians(yaw));
		return fwdZ;
	}
	
	private Matrix3D perspective(float fovy, float aspect, float n, float f)
	{	float q = 1.0f / ((float) Math.tan(Math.toRadians(0.5f * fovy)));
		float A = q / aspect;
		float B = (n + f) / (n - f);
		float C = (2.0f * n * f) / (n - f);
		Matrix3D r = new Matrix3D();
		r.setElementAt(0,0,A);
		r.setElementAt(1,1,q);
		r.setElementAt(2,2,B);
		r.setElementAt(3,2,-1.0f);
		r.setElementAt(2,3,C);
		r.setElementAt(3,3,0.0f);
		return r;
	}


	private Matrix3D lookAt(Point3D eye, Point3D target, Vector3D y)
	{	Vector3D eyeV = new Vector3D(eye);
		Vector3D targetV = new Vector3D(target);
		Vector3D fwd = (targetV.minus(eyeV)).normalize();
		Vector3D side = (fwd.cross(y)).normalize();
		Vector3D up = (side.cross(fwd)).normalize();
		Matrix3D look = new Matrix3D();
		look.setElementAt(0,0, side.getX());
		look.setElementAt(1,0, up.getX());
		look.setElementAt(2,0, -fwd.getX());
		look.setElementAt(3,0, 0.0f);
		look.setElementAt(0,1, side.getY());
		look.setElementAt(1,1, up.getY());
		look.setElementAt(2,1, -fwd.getY());
		look.setElementAt(3,1, 0.0f);
		look.setElementAt(0,2, side.getZ());
		look.setElementAt(1,2, up.getZ());
		look.setElementAt(2,2, -fwd.getZ());
		look.setElementAt(3,2, 0.0f);
		look.setElementAt(0,3, side.dot(eyeV.mult(-1)));
		look.setElementAt(1,3, up.dot(eyeV.mult(-1)));
		look.setElementAt(2,3, (fwd.mult(-1)).dot(eyeV.mult(-1)));
		look.setElementAt(3,3, 1.0f);
		return(look);
	}
}

