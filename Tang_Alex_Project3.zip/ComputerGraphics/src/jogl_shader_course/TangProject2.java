package jogl_shader_course;

import graphicslib3D.*;
import graphicslib3D.shape.*;
import graphicslib3D.GLSLUtils.*;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.nio.*;
import javax.swing.*;

import static com.jogamp.opengl.GL.GL_ARRAY_BUFFER;
import static com.jogamp.opengl.GL4.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.math.Matrix4;
import com.jogamp.opengl.util.*;
import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.util.texture.*;

public class TangProject2 extends JFrame implements GLEventListener, KeyListener{

	private GLCanvas myCanvas;
	private int rendering_program;
	
	//Set up variables
	private static final float camSpeed = 0.75f;
	private float cameraX, cameraY, cameraZ;
	private float sunLocX, sunLocY, sunLocZ;
	private Point3D cameraPos;
	private Point3D origin;
	private Vector3D fwd;
	private Vector3D up;
	private Matrix3D camera = new Matrix3D();
	private boolean toggleAxes = true;
	private float pitch = 0.0f;
	private float yaw = -90.0f;
	
	//Set up VAO and VBO
	private int vao[] = new int[1];	
	private int vbo[] = new int[20];
	
	//Set up Textures
	private int sunTexture;
	private Texture joglSunTexture;
	
	private int pOneTexture;
	private Texture joglPOneTexture;
	private int moonOneTexture;
	private Texture joglMoonOneTexture;
	
	private int pTwoTexture;
	private Texture joglPTwoTexture;
	private int moonTwoTexture;
	private Texture joglMoonTwoTexture;
	
	private int meTexture;
	private Texture joglMeTexture;
	
	private int redTexture;
	private Texture joglRedTexture;
	
	private int blueTexture;
	private Texture joglBlueTexture;
	
	private int greenTexture;
	private Texture joglGreenTexture;
	
	//Set up objects
	private Sphere sun = new Sphere(24);
	private Sphere earth = new Sphere(24);
	private Sphere moon = new Sphere(24);
	private Sphere mars = new Sphere(24);
	private Sphere phobos = new Sphere(24);
	private PentagonalPrism me = new PentagonalPrism();
	
	//Set up Matrix Stack
	private	MatrixStack mvStack = new MatrixStack(20);
	
	private GLSLUtils util = new GLSLUtils();
	
	public TangProject2() {
		setTitle("Project 2 - Solar System");
		setSize(800, 800);
		myCanvas = new GLCanvas();
		myCanvas.addGLEventListener(this);
		myCanvas.addKeyListener(this);;
		getContentPane().add(myCanvas);
		this.setVisible(true);
		FPSAnimator animator = new FPSAnimator(myCanvas, 50);
		animator.start();
	}
	
	public void init(GLAutoDrawable drawable) {
		rendering_program = createShaderProgram();
        
		setupVertices();
		cameraX = 0.0f; cameraY = 0.0f; cameraZ = 15.0f;
		sunLocX = 0.0f; sunLocY = 0.0f; sunLocZ = 0.0f;
		cameraPos = new Point3D(cameraX, cameraY, cameraZ);
		origin = new Point3D(sunLocX, sunLocY, sunLocZ);
		up = new Vector3D (0.0f, 1.0f, 0.0f);
		
		//Set up Textures
		joglSunTexture = loadTexture("textures/sun.jpg");
		sunTexture = joglSunTexture.getTextureObject();
		
		joglPOneTexture = loadTexture("textures/earth.jpg");
		pOneTexture = joglPOneTexture.getTextureObject();
		joglMoonOneTexture = loadTexture("textures/moon.jpg");
		moonOneTexture = joglMoonOneTexture.getTextureObject();
		
		joglPTwoTexture = loadTexture("textures/mars.jpg");
		pTwoTexture = joglPTwoTexture.getTextureObject();
		joglMoonTwoTexture = loadTexture("textures/phobos.jpg");
		moonTwoTexture = joglMoonTwoTexture.getTextureObject();
		
		joglMeTexture = loadTexture("textures/papa.jpg");	//I also have a Dr. Papa texture
		meTexture = joglMeTexture.getTextureObject();
		
		joglRedTexture = loadTexture("textures/redWall.jpg");
		redTexture = joglRedTexture.getTextureObject();
		
		joglBlueTexture = loadTexture("textures/blueWall.jpg");
		blueTexture = joglBlueTexture.getTextureObject();
		
		joglGreenTexture = loadTexture("textures/greenWall.jpg");
		greenTexture = joglGreenTexture.getTextureObject();
		
	}
	
	public void display(GLAutoDrawable drawable) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
	
		gl.glClear(GL_DEPTH_BUFFER_BIT);
		float bkg[] = { 0.0f, 0.0f, 0.0f, 1.0f };
		FloatBuffer bkgBuffer = Buffers.newDirectFloatBuffer(bkg);
		gl.glClearBufferfv(GL_COLOR, 0, bkgBuffer);

		gl.glClear(GL_DEPTH_BUFFER_BIT);

		gl.glUseProgram(rendering_program);
		
		int mv_loc = gl.glGetUniformLocation(rendering_program, "mv_matrix");
		int proj_loc = gl.glGetUniformLocation(rendering_program, "proj_matrix");

		float aspect = (float) myCanvas.getWidth() / (float) myCanvas.getHeight();
		Matrix3D pMat = perspective(60.0f, aspect, 0.1f, 1000.0f);
		
		//Used for the free camera
		fwd = new Vector3D(getFwdX(), getFwdY(), getFwdZ());
		
		camera = lookAt(cameraPos, origin, up);
		// push view matrix onto the stack
		mvStack.pushMatrix();
		mvStack.loadMatrix(camera);
		
		//Used for the fixed camera
		//mvStack.rotate(pitch, 1, 0, 0);
		//mvStack.rotate(-yaw, 0, 1, 0);
		
		double amt = (double)(System.currentTimeMillis())/1000.0;

		gl.glUniformMatrix4fv(proj_loc, 1, false, pMat.getFloatValues(), 0);
		
		// ----------------------  Sun  
		mvStack.pushMatrix();
		mvStack.translate(sunLocX, sunLocY, sunLocZ);
		mvStack.pushMatrix();
		mvStack.rotate((System.currentTimeMillis())/10.0,0.0,1.0,0.0);
		gl.glUniformMatrix4fv(mv_loc, 1, false, mvStack.peek().getFloatValues(), 0);
		gl.glBindVertexArray(vao[0]);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, sunTexture);
		gl.glEnable(GL_DEPTH_TEST);
		gl.glDrawArrays(GL_TRIANGLES, 0, sun.getIndices().length); 
		mvStack.popMatrix();

		//-----------------------  Planet One: Earth
		mvStack.pushMatrix();
		mvStack.translate(Math.sin(amt)*4.0f, 0.0f, Math.cos(amt)*4.0f);
		mvStack.pushMatrix();
		mvStack.rotate((System.currentTimeMillis())/10.0,0.0,1.0,0.0);
		gl.glUniformMatrix4fv(mv_loc, 1, false, mvStack.peek().getFloatValues(), 0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, pOneTexture);
		gl.glDrawArrays(GL_TRIANGLES, 0, earth.getIndices().length);	
		mvStack.popMatrix();

		//-----------------------  Moon One: Moon
		mvStack.pushMatrix();
		mvStack.translate(0.0f, Math.sin(amt)*2.0f, Math.cos(amt)*2.0f);
		mvStack.rotate((System.currentTimeMillis())/10.0,0.0,0.0,1.0);
		mvStack.scale(0.25, 0.25, 0.25);
		gl.glUniformMatrix4fv(mv_loc, 1, false, mvStack.peek().getFloatValues(), 0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, moonOneTexture);
		gl.glDrawArrays(GL_TRIANGLES, 0, moon.getIndices().length);
		mvStack.popMatrix();  
		mvStack.popMatrix();  
		
		//-----------------------  Planet Two: Mars
		mvStack.pushMatrix();
		mvStack.translate(Math.sin(amt*.4)*8.0f, 0.0f, Math.cos(amt*.4)*8.0f);
		mvStack.pushMatrix();
		mvStack.rotate((System.currentTimeMillis())/20.0,0.0,1.0,0.0);
		gl.glUniformMatrix4fv(mv_loc, 1, false, mvStack.peek().getFloatValues(), 0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[6]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[7]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, pTwoTexture);
		gl.glDrawArrays(GL_TRIANGLES, 0, mars.getIndices().length);	
		mvStack.popMatrix();
		
		//-----------------------  Moon Two: Phobos
		mvStack.pushMatrix();
		mvStack.translate(0.0f, Math.sin(amt*.6)*3.0f, Math.cos(amt*.6)*3.0f);
		mvStack.rotate((System.currentTimeMillis())/15.0,0.0,0.0,1.0);
		mvStack.scale(0.25, 0.25, 0.25);
		gl.glUniformMatrix4fv(mv_loc, 1, false, mvStack.peek().getFloatValues(), 0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[8]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[9]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, moonTwoTexture);
		gl.glDrawArrays(GL_TRIANGLES, 0, phobos.getIndices().length);
		mvStack.popMatrix(); 
		mvStack.popMatrix();  
		
		//-----------------------  Planet Three: Pentagonal Prism
		mvStack.pushMatrix();
		mvStack.translate(Math.sin(amt*.1)*15.0f, 0.0f, Math.cos(amt*.1)*15.0f);
		mvStack.pushMatrix();
		mvStack.rotate((System.currentTimeMillis())/30.0,0.0,0.0,1.0);
		gl.glUniformMatrix4fv(mv_loc, 1, false, mvStack.peek().getFloatValues(), 0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[10]);
		gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(0);
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[11]);
		gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
		gl.glEnableVertexAttribArray(1);
		gl.glActiveTexture(GL_TEXTURE0);
		gl.glBindTexture(GL_TEXTURE_2D, meTexture);
		gl.glDrawArrays(GL_TRIANGLES, 0, me.getIndices().length);
		mvStack.popMatrix();
		mvStack.popMatrix();
		mvStack.popMatrix();
		
		//-----------------------  World Axes
		if(toggleAxes) {
			mvStack.pushMatrix();
			gl.glUniformMatrix4fv(mv_loc, 1, false, mvStack.peek().getFloatValues(), 0);
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[12]);
			gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(0);
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[13]);
			gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(1);
			gl.glActiveTexture(GL_TEXTURE0);
			gl.glBindTexture(GL_TEXTURE_2D, redTexture);
			gl.glDrawArrays(GL_LINES, 0, 6);
			
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[14]);
			gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(0);
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[15]);
			gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(1);
			gl.glActiveTexture(GL_TEXTURE0);
			gl.glBindTexture(GL_TEXTURE_2D, greenTexture);
			gl.glDrawArrays(GL_LINES, 0, 6);
			
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[16]);
			gl.glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(0);
			gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[17]);
			gl.glVertexAttribPointer(1, 2, GL_FLOAT, false, 0, 0);
			gl.glEnableVertexAttribArray(1);
			gl.glActiveTexture(GL_TEXTURE0);
			gl.glBindTexture(GL_TEXTURE_2D, blueTexture);
			gl.glDrawArrays(GL_LINES, 0, 6);
			mvStack.popMatrix();	
		}	
		mvStack.popMatrix();
	}	
	
	//Set vertices 
	private void setupVertices() {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		gl.glGenVertexArrays(vao.length, vao, 0);
		gl.glBindVertexArray(vao[0]);
		gl.glGenBuffers(vbo.length, vbo, 0);

		setUpSphere(sun, 0);
		setUpSphere(earth, 1);
		setUpSphere(moon, 2);
		setUpSphere(mars, 3);
		setUpSphere(phobos, 4);
		setPentaVertices(me, 5);
		setUpXAxis(6);
		setUpYAxis(7);
		setUpZAxis(8);

	}
	
	private void setUpXAxis(int n) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		float[] lineVertices = {
		-500.0f,0.0f,0.0f,
		500.0f,0.0f,0.0f};
		
		float[] texCoord = {0.0f,0.0f, 1.0f,1.0f};
	
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(lineVertices);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n+1]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(texCoord);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);

	}
	private void setUpYAxis(int n) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		float[] lineVertices = {
		0.0f,-500.0f,0.0f,
		0.0f,500.0f,0.0f};
		
		float[] texCoord = {0.0f,1.0f, 1.0f,1.0f};
	
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(lineVertices);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n+1]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(texCoord);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);

	}
	private void setUpZAxis(int n) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		float[] lineVertices = {
		0.0f,0.0f,-500.0f,
		0.0f,0.0f,500.0f};
		
		float[] texCoord = {0.0f,1.0f, 1.0f,1.0f};
	
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(lineVertices);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);
		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n+1]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(texCoord);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);

	}
	
	private void setUpSphere(Sphere s, int n) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		
		Vertex3D[] vertices = s.getVertices();
		int[] indices = s.getIndices();
		
		float[] pvalues = new float[indices.length*3];
		float[] tvalues = new float[indices.length*2];		
		for (int i=0; i<indices.length; i++)
		{	
			pvalues[i*3] = (float) (vertices[indices[i]]).getX();
			pvalues[i*3+1] = (float) (vertices[indices[i]]).getY();
			pvalues[i*3+2] = (float) (vertices[indices[i]]).getZ();
			tvalues[i*2] = (float) (vertices[indices[i]]).getS();
			tvalues[i*2+1] = (float) (vertices[indices[i]]).getT();
		}		
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(pvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n+1]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(tvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);
	}
	
	//Set Vertices for Pentagonal Prism
	private void setPentaVertices(PentagonalPrism p, int n) {
		GL4 gl = (GL4) GLContext.getCurrentGL();
		
		Vertex3D[] vertices = p.getVertices();
		int[] indices = p.getIndices();
			
		float[] pvalues = new float[indices.length*3];
		float[] tvalues = new float[indices.length*2];		
		for (int i=0; i<indices.length; i++)
		{	
			pvalues[i*3] = (float) (vertices[indices[i]]).getX();
			pvalues[i*3+1] = (float) (vertices[indices[i]]).getY();
			pvalues[i*3+2] = (float) (vertices[indices[i]]).getZ();
			tvalues[i*2] = (float) (vertices[indices[i]]).getS();
			tvalues[i*2+1] = (float) (vertices[indices[i]]).getT();
		}
			
		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n]);
		FloatBuffer vertBuf = Buffers.newDirectFloatBuffer(pvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, vertBuf.limit()*4, vertBuf, GL_STATIC_DRAW);

		gl.glBindBuffer(GL_ARRAY_BUFFER, vbo[2*n+1]);
		FloatBuffer texBuf = Buffers.newDirectFloatBuffer(tvalues);
		gl.glBufferData(GL_ARRAY_BUFFER, texBuf.limit()*4, texBuf, GL_STATIC_DRAW);
	}

	
	private Matrix3D lookAt(Point3D eye, Point3D target, Vector3D y) {
		Vector3D eyeV = new Vector3D(eye);
		
		//Used for fixed camera, target only needed for fixed
		//Vector3D targetV = new Vector3D(target);
		//Vector3D fwd = (targetV.minus(eyeV)).normalize();
		
		Vector3D side = (fwd.cross(y)).normalize();
		Vector3D up = (side.cross(fwd)).normalize();
		
		Matrix3D look = new Matrix3D();
		look.setElementAt(0, 0, side.getX());
		look.setElementAt(1, 0, up.getX());
		look.setElementAt(2, 0, -fwd.getX());
		look.setElementAt(3, 0, 0.0f);
		look.setElementAt(0, 1, side.getY());
		look.setElementAt(1, 1, up.getY());
		look.setElementAt(2, 1, -fwd.getY());
		look.setElementAt(3, 1, 0.0f);
		look.setElementAt(0, 2, side.getZ());
		look.setElementAt(1, 2, up.getZ());
		look.setElementAt(2, 2, -fwd.getZ());
		look.setElementAt(3, 2, 0.0f);
		look.setElementAt(0, 3, side.dot(eyeV.mult(-1)));
		look.setElementAt(1, 3, up.dot(eyeV.mult(-1)));
		look.setElementAt(2, 3, fwd.mult(-1).dot(eyeV.mult(-1)));
		look.setElementAt(3, 3, 1.0f);
		return(look);
	}
	
	
	public Texture loadTexture(String textureFileName)
	{	Texture tex = null;
		try { tex = TextureIO.newTexture(new File(textureFileName), false); }
		catch (Exception e) { e.printStackTrace(); }
		return tex;
	}
	
	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {	}
	
	public void dispose(GLAutoDrawable drawable) {}
	
	public static void main(String[] args) {
		new TangProject2();
	}
	
	@Override
	public void keyPressed(KeyEvent ke) {
		char pressed = ke.getKeyChar();
		int arrowKeys = ke.getKeyCode();
		switch (pressed) {
		case 'w':
			cameraPos = cameraPos.add(new Point3D(camera.elementAt(2, 0), camera.elementAt(2, 1), camera.elementAt(2, 2)).mult(-camSpeed));
			break;
		case 's':
			cameraPos = cameraPos.add(new Point3D(camera.elementAt(2, 0), camera.elementAt(2, 1), camera.elementAt(2, 2)).mult(camSpeed));
			break;
		case 'a':
			cameraPos = cameraPos.add(new Point3D(camera.elementAt(0, 0), camera.elementAt(0, 1), camera.elementAt(0, 2)).mult(-camSpeed));
			break;
		case 'd':
			cameraPos = cameraPos.add(new Point3D(camera.elementAt(0, 0), camera.elementAt(0, 1), camera.elementAt(0, 2)).mult(camSpeed));
			break;
		case 'e':
			cameraPos = cameraPos.add(new Point3D(camera.elementAt(1, 0), camera.elementAt(1, 1), camera.elementAt(1, 2)).mult(-camSpeed));
			break;
		case 'q':
			cameraPos = cameraPos.add(new Point3D(camera.elementAt(1, 0), camera.elementAt(1, 1), camera.elementAt(1, 2)).mult(camSpeed));
			break;
		case ' ':
			toggleAxes = !toggleAxes;
		}	
		switch(arrowKeys) {
		case KeyEvent.VK_UP:
			pitch++;
			break;
		case KeyEvent.VK_DOWN:
			pitch--;
			break;
		case KeyEvent.VK_RIGHT:
			yaw++;
			break;
		case KeyEvent.VK_LEFT:
			yaw--;
			break;
		}
	}

	@Override
	public void keyReleased(KeyEvent ke) {}

	@Override
	public void keyTyped(KeyEvent ke) {	}
	
	private int createShaderProgram() {
		GL4 gl = (GL4) GLContext.getCurrentGL();

		String vshaderSource[] = util.readShaderSource("SolarSystem/vert.shader");	
		String fshaderSource[] = util.readShaderSource("SolarSystem/frag.shader");

		int vShader = gl.glCreateShader(GL_VERTEX_SHADER);
		int fShader = gl.glCreateShader(GL_FRAGMENT_SHADER);

		gl.glShaderSource(vShader, vshaderSource.length, vshaderSource, null, 0);
		gl.glShaderSource(fShader, fshaderSource.length, fshaderSource, null, 0);

		gl.glCompileShader(vShader);
		gl.glCompileShader(fShader);

		int vfprogram = gl.glCreateProgram();
		gl.glAttachShader(vfprogram, vShader);
		gl.glAttachShader(vfprogram, fShader);
		gl.glLinkProgram(vfprogram);
		return vfprogram;
	}
	
	private Matrix3D perspective(float fovy, float aspect, float n, float f)
	{	float q = 1.0f / ((float) Math.tan(Math.toRadians(0.5f * fovy)));
		float A = q / aspect;
		float B = (n + f) / (n - f);
		float C = (2.0f * n * f) / (n - f);
		Matrix3D r = new Matrix3D();
		r.setElementAt(0,0,A);
		r.setElementAt(1,1,q);
		r.setElementAt(2,2,B);
		r.setElementAt(3,2,-1.0f);
		r.setElementAt(2,3,C);
		r.setElementAt(3,3,0.0f);
		return r;
	}
	
	
	
	public double getFwdX() {
		double fwdX = Math.cos(Math.toRadians(pitch)) * Math.cos(Math.toRadians(yaw));
		return fwdX;
	}

	public double getFwdY() {
		double fwdY = Math.sin(Math.toRadians(pitch));
		return fwdY;
	}

	public double getFwdZ() {
		double fwdZ =  Math.cos(Math.toRadians(pitch)) * Math.sin(Math.toRadians(yaw));
		return fwdZ;
	}
}
